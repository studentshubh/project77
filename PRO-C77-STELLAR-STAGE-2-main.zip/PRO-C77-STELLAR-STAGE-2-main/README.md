# PRO-C77-STELLAR-STAGE-2
In Class 77, We Have Designed The Home Screen By Adding The Buttons For Different Screens And Adding The Background Image To The Screen. You Will Have To Add A Background Image, And Style Different Components Of The Home Screen Of The Stellar App Created In The Last Class.
